
document.addEventListener('DOMContentLoaded',function(){
  // demo reviews
  const reviews = [
    {name:'Алина',text:'Красивое место, приветливый персонал. Очень понравилось!',stars:5},
    {name:'Игорь',text:'Отличный семейный отдых.',stars:4},
    {name:'Семья Каримовых',text:'Дети в восторге, вернёмся ещё.',stars:5},
  ];
  const rnode = document.getElementById('reviewsList');
  reviews.forEach(r=>{
    const el = document.createElement('div');
    el.className='review';
    el.innerHTML = `<strong>${r.name}</strong><p>${r.text}</p><div class="stars">${'★'.repeat(r.stars)}${'☆'.repeat(5-r.stars)}</div>`;
    rnode.appendChild(el);
  });

  // booking form -> whatsapp
  document.getElementById('bookingForm').addEventListener('submit',function(e){
    e.preventDefault();
    const fd = new FormData(e.target);
    const name = fd.get('name') || '';
    const phone = fd.get('phone') || '';
    const checkin = fd.get('checkin') || '';
    const pkg = fd.get('package') || '';
    const text = encodeURIComponent(`Заявка: ${name} - ${phone}. Заезд: ${checkin}. Пакет: ${pkg}`);
    window.open('https://wa.me/77001234567?text='+text,'_blank');
  });

  // mobile menu
  document.querySelector('.menu').addEventListener('click',function(){
    const nav = document.querySelector('.nav');
    if(nav.style.display==='flex') nav.style.display='none'; else nav.style.display='flex';
  });
});
